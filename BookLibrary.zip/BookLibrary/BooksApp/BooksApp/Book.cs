﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BooksApp
{
    public class Book
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public string Author { get; set; }
        public DateTime RegistrationTimeStamp { get; set; }
        public int Category { get; set; }
        public String Description { get; set; }
    }
}
