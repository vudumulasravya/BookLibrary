﻿using System;
using System.Collections.Specialized;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace BooksApp
{
    class Program
    {
        static HttpClient client = new HttpClient();
        static void Main(string[] args)
        {
            //PostBooks();
            GetBooks();
        }

        public static void PostBooks()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44305/api/Books");

                var book = new Book
                {
                    BookId = 6,
                    BookName = "Name 06",
                    Author = "Author 06",
                    RegistrationTimeStamp = DateTime.Now,
                    Category = 3,
                    Description = "Described about .net core"
                };
                var postTask = client.PostAsJsonAsync<Book>("Books", book);
                postTask.Wait();

                var result = postTask.Result;
                if (result.IsSuccessStatusCode)
                {
                    var readTask = result.Content.ReadAsAsync<int>();
                    readTask.Wait();

                    var insertedBook = readTask.Result;
                    Console.WriteLine("Book inserted with id: {6}", insertedBook);
                }
                else
                {
                    Console.WriteLine(result.StatusCode);
                }

            }
        }

        public static void GetBooks()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost:44305/api/Books");
                //HTTP GET
                var responseTask = client.GetAsync("Books");
                responseTask.Wait();

                var result = responseTask.Result;
                if (result.IsSuccessStatusCode)
                {

                    var readTask = result.Content.ReadAsAsync<Book[]>();
                    readTask.Wait();

                    var books = readTask.Result;

                    foreach (var book in books)
                    {
                        Console.WriteLine("{0} : {1}", book.BookId, book.BookName);
                    }
                }
            }
            Console.ReadLine();

        }

    }
}
