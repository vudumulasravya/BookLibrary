﻿using BookServiceAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookServiceAPI.Repositories
{
    public interface IBookRepository
    {
        Task<IEnumerable<Book>> Get();
        Task<Book> GetBook(int id);
        Task<int> Create(Book book);
        Task<Book> Update(Book book);
    }
}
