﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BookServiceAPI.Models;
using BookServiceAPI.Repositories;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BookServiceAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        private readonly IBookRepository _bookRepository;

        public BooksController(IBookRepository bookRepository)
        {
            _bookRepository = bookRepository;
        }
        [HttpGet]
        public async Task<IEnumerable<Book>> GetBooks()
        {
            return await _bookRepository.Get();
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Book>> GetBooks(int id)
        {
            return await _bookRepository.GetBook(id);
        }

        [HttpPost]
        public async Task<ActionResult<int>> CreateBook([FromBody]Book book)
        {
            return await _bookRepository.Create(book);
        }

        [HttpPut]
        public async Task<ActionResult<Book>> UpdateBook(int id, [FromBody]Book book)
        {
            if (id != book.BookId)
            {
                return BadRequest();
            }

            var _book = await _bookRepository.Update(book);

            return CreatedAtAction(nameof(GetBooks), new { id = _book.BookId }, _book);

        }
    }
}