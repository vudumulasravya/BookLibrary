﻿using Microsoft.EntityFrameworkCore;

namespace BookServiceAPI.Models
{
    public class BookContext : DbContext
    {
        public BookContext(DbContextOptions<BookContext> dbcontextOptions)
            : base(dbcontextOptions)
        {
            Database.EnsureCreated();
        }
        public DbSet<Book> Books { get; set; }
    }

}
