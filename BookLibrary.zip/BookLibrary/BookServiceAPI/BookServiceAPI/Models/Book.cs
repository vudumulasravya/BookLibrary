﻿using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BookServiceAPI.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public string BookName { get; set; }
        public string Author { get; set; }
        public DateTime RegistrationTimeStamp { get; set; }
        public int Category { get; set; }
        public String Description { get; set; }
    }

    public class BookValidator : AbstractValidator<Book>
    {
        public BookValidator()
        {
            RuleFor(x => x.BookId).GreaterThan(0).WithMessage("Enter a valid Book Id.");
            RuleFor(x => x.Category).InclusiveBetween(1, 4).WithMessage("Provide a valid category from Thriller-1, History-2, Drama-3, Biography-4");
            RuleFor(x => x.BookName).NotEmpty().WithMessage("Must Provide Book Name");
        }
    }
}
